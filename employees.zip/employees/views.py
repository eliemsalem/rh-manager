import pandas as pd
from django.db.models import Q
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from .models import Employee
from .forms import EmployeeForm


# ---------------------------
# 🔍 Filtrage des employés
# ---------------------------
def _filtered_queryset(request, include_inactive=False):
    q = request.GET.get("q", "").strip()
    qs = Employee.objects.all()
    if not include_inactive:
        qs = qs.filter(actif=True)
    if q:
        qs = qs.filter(
            Q(nom__icontains=q)
            | Q(prenom__icontains=q)
            | Q(project__icontains=q)
            | Q(country__icontains=q)
            | Q(bank_name__icontains=q)
            | Q(email__icontains=q)
            | Q(iban__icontains=q)
            | Q(swift__icontains=q)
        )
    return qs, q


# ---------------------------
# 👩 Liste et détail
# ---------------------------
def employee_list(request):
    employees, q = _filtered_queryset(request, include_inactive=False)
    return render(request, "employees/list.html", {"employees": employees, "query": q})


def employee_inactive_list(request):
    employees, q = _filtered_queryset(request, include_inactive=True)
    employees = employees.filter(actif=False)
    return render(request, "employees/inactive_list.html", {"employees": employees, "query": q})


def employee_detail(request, pk):
    employee = get_object_or_404(Employee, pk=pk)
    if request.method == "POST":
        form = EmployeeForm(request.POST, instance=employee)
        if form.is_valid():
            form.save()
            messages.success(request, f"L’employé {employee.prenom} {employee.nom} a été mis à jour.")
            return redirect("employees:employee_detail", pk=employee.pk)
    else:
        form = EmployeeForm(instance=employee)
    return render(request, "employees/detail.html", {"employee": employee, "form": form})


# ---------------------------
# ➕ Ajouter un employé
# ---------------------------
def employee_add(request):
    if request.method == "POST":
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Employé ajouté avec succès ✅")
            return redirect("employees:employee_list")
        else:
            messages.error(request, "Veuillez corriger les erreurs du formulaire.")
    else:
        form = EmployeeForm()
    return render(request, "employees/add.html", {"form": form})


# ---------------------------
# 🗑️ Supprimer un employé
# ---------------------------
def employee_delete(request, pk):
    emp = get_object_or_404(Employee, pk=pk)
    if request.method == "POST":
        emp.delete()
        messages.success(request, f"L’employé {emp.prenom} {emp.nom} a été supprimé 🗑️.")
        return redirect("employees:employee_list")
    return render(request, "employees/delete_confirm.html", {"employee": emp})


# ---------------------------
# 📤 Importer depuis Excel
# ---------------------------
def employee_import_excel(request):
    """Importe ou met à jour les employés depuis un fichier Excel (.xlsx)"""
    if request.method == "POST" and request.FILES.get("file"):
        file = request.FILES["file"]

        # Sécurité basique : vérifie l’extension
        if not file.name.lower().endswith(".xlsx"):
            messages.error(request, "Veuillez importer un fichier Excel (.xlsx).")
            return redirect("employees:employee_import_excel")

        try:
            df = pd.read_excel(file)
        except Exception as e:
            messages.error(request, f"Erreur lors de la lecture du fichier : {e}")
            return redirect("employees:employee_import_excel")

        # Vérifie que les colonnes attendues existent
        required_cols = {"prenom", "nom", "email"}
        missing_cols = required_cols - set(df.columns)
        if missing_cols:
            messages.error(request, f"Colonnes manquantes : {', '.join(missing_cols)}")
            return redirect("employees:employee_import_excel")

        added, updated = 0, 0
        for _, row in df.iterrows():
            # Conversion booléenne robuste
            actif_val = str(row.get("actif", "True")).strip().lower() in ("1", "true", "yes", "oui")

            emp, created = Employee.objects.update_or_create(
                email=row.get("email"),
                defaults={
                    "prenom": row.get("prenom", "").strip(),
                    "nom": row.get("nom", "").strip(),
                    "salaire_net": float(row.get("salaire_net", 0) or 0),
                    "devise": row.get("devise", "EUR") or "EUR",
                    "actif": actif_val,
                    "project": row.get("project", "") or "",
                    "iban": row.get("iban", "") or "",
                    "swift": row.get("swift", "") or "",
                    "bank_name": row.get("bank_name", "") or "",
                    "country": row.get("country", "") or "",
                },
            )
            if created:
                added += 1
            else:
                updated += 1

        messages.success(request, f"{added} employés ajoutés, {updated} mis à jour depuis Excel ✅")
        return redirect("employees:employee_list")

    return render(request, "employees/import.html")
