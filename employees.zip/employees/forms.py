from django import forms
from .models import Employee

class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = "__all__"  # ✅ permet d'éditer salaire_net, devise, etc.
        widgets = {
            "pt_date": forms.DateInput(attrs={"type": "date", "class": "form-control"}),
            "ft_date": forms.DateInput(attrs={"type": "date", "class": "form-control"}),
            "last_day": forms.DateInput(attrs={"type": "date", "class": "form-control"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # un peu de mise en forme Bootstrap par défaut
        for name, field in self.fields.items():
            if not getattr(field.widget, "attrs", None):
                field.widget.attrs = {}
            field.widget.attrs.setdefault("class", "form-control")
