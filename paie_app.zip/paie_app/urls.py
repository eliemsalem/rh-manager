from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # --- Admin Django ---
    path("admin/", admin.site.urls),

    # --- Application principale (Employés) ---
    # L’app employees gère la page d’accueil (liste des employés actifs)
    path("", include("employees.urls")),

    # --- Application Paie ---
    path("payroll/", include("payroll.urls")),
]

# --- Gestion des fichiers média (PDF, images, etc.) ---
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
