from datetime import date
from calendar import monthrange
import os, io, zipfile
from django.conf import settings
from django.http import FileResponse, HttpResponse
from django.shortcuts import get_object_or_404, render, redirect
from django.db.models import Q
from employees.models import Employee
from .models import Payroll
from .forms import PayrollForm
from .utils.pdf_generator import generate_paie_pdf

# ---------- Helpers ----------
def _year_month_from_request(request):
    try:
        y = int(request.GET.get("year") or date.today().year)
        m = int(request.GET.get("month") or date.today().month)
    except Exception:
        y, m = date.today().year, date.today().month
    return y, m

def _periode_date(y, m):
    return date(y, m, 1)

def _media_month_folder(y, m):
    base = getattr(settings, "MEDIA_ROOT", os.path.join(settings.BASE_DIR, "media"))
    folder = os.path.join(base, "payroll", f"{y:04d}-{m:02d}")
    os.makedirs(folder, exist_ok=True)
    return folder

# ---------- Pages ----------
def payroll_list(request):
    year, month = _year_month_from_request(request)
    periode = _periode_date(year, month)

    q = (request.GET.get("q") or "").strip()
    qs = Payroll.objects.filter(periode=periode).select_related("employee")
    if q:
        qs = qs.filter(
            Q(employee__nom__icontains=q) |
            Q(employee__prenom__icontains=q) |
            Q(employee__email__icontains=q) |
            Q(employee__project__icontains=q)
        )

    # For month/year dropdowns
    months = [(i, date(2000, i, 1).strftime("%B")) for i in range(1, 12+1)]
    years = list(range(date.today().year - 5, date.today().year + 2))

    return render(request, "payroll/list.html", {
        "items": qs.order_by("employee__nom", "employee__prenom"),
        "year": year,
        "month": month,
        "months": months,
        "years": years,
        "query": q,
    })

def payroll_edit(request, pk):
    obj = get_object_or_404(Payroll, pk=pk)
    if request.method == "POST":
        form = PayrollForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            return redirect("payroll:payroll_list")

    else:
        form = PayrollForm(instance=obj)
    return render(request, "payroll/edit.html", {"form": form, "payroll": obj})

def generate_month_for_actives(request):
    """Crée (ou met à jour) les lignes de paie du mois pour tous les employés actifs."""
    year, month = _year_month_from_request(request)
    periode = _periode_date(year, month)
    created, updated = 0, 0

    for emp in Employee.objects.filter(actif=True):
        defaults = {
            "salaire_base": emp.salaire_net or 0,
            "devise": emp.devise or "EUR",
        }
        obj, was_created = Payroll.objects.update_or_create(
            employee=emp, periode=periode, defaults=defaults
        )
        created += int(was_created)
        updated += int(not was_created)

    # Optionally, pre-generate PDFs on the fly
    # (we just ensure folder exists; individual PDFs are generated per request)
    _media_month_folder(year, month)

    return redirect(f"/payroll/?year={year}&month={month}")

# ---------- PDF (1 fiche) ----------
def payroll_pdf(request, pk):
    """Génère une fiche de paie PDF professionnelle avec logo."""
    obj = get_object_or_404(Payroll, pk=pk)
    year, month = obj.periode.year, obj.periode.month

    # Crée le dossier du mois si besoin
    folder = _media_month_folder(year, month)
    filename = f"pay_{obj.employee.pk}_{year}-{month:02d}.pdf"
    pdf_path = os.path.join(folder, filename)

    # Génère le PDF stylisé
    generate_paie_pdf(obj, pdf_path)

    # Retourne le PDF au navigateur
    return FileResponse(open(pdf_path, "rb"), as_attachment=True, filename=filename)


# ---------- ZIP all PDFs for a month ----------
# ---------- ZIP all PDFs for a month ----------
def bulk_zip_month(request, year, month):
    """Crée un ZIP contenant toutes les fiches de paie du mois, en générant les PDF manquants."""
    periode = _periode_date(year, month)
    folder = _media_month_folder(year, month)

    # Génère les PDFs manquants avec le nouveau générateur stylisé
    for p in Payroll.objects.filter(periode=periode):
        pdf_path = os.path.join(folder, f"pay_{p.employee.pk}_{year}-{month:02d}.pdf")
        if not os.path.exists(pdf_path):
            generate_paie_pdf(p, pdf_path)

    # Construit le ZIP en mémoire
    mem = io.BytesIO()
    with zipfile.ZipFile(mem, "w", zipfile.ZIP_DEFLATED) as zf:
        for fname in sorted(os.listdir(folder)):
            if fname.endswith(".pdf"):
                zf.write(os.path.join(folder, fname), arcname=fname)

    mem.seek(0)
    resp = HttpResponse(mem.read(), content_type="application/zip")
    resp["Content-Disposition"] = f'attachment; filename="payroll_{year}-{month:02d}.zip"'
    return resp

