from django import forms
from datetime import date
from .models import Payroll

# --- Listes déroulantes ---
MONTHS = [
    (1, "Janvier"), (2, "Février"), (3, "Mars"), (4, "Avril"),
    (5, "Mai"), (6, "Juin"), (7, "Juillet"), (8, "Août"),
    (9, "Septembre"), (10, "Octobre"), (11, "Novembre"), (12, "Décembre"),
]

YEARS = [(y, str(y)) for y in range(2020, date.today().year + 3)]  # 2020 → 2028


class PayrollForm(forms.ModelForm):
    # On remplace le champ "periode" par deux sélecteurs Mois / Année
    mois = forms.ChoiceField(choices=MONTHS, label="Mois")
    annee = forms.ChoiceField(choices=YEARS, label="Année")

    class Meta:
        model = Payroll
        exclude = ("periode",)  # on cache le champ "periode" réel
        widgets = {
            "employee": forms.Select(attrs={"class": "form-select"}),
            "salaire_base": forms.NumberInput(attrs={"class": "form-control"}),
            "heures_supp": forms.NumberInput(attrs={"class": "form-control"}),
            "montant_heures_supp": forms.NumberInput(attrs={"class": "form-control"}),
            "remboursement": forms.NumberInput(attrs={"class": "form-control"}),
            "remboursement_comment": forms.TextInput(attrs={"class": "form-control"}),
            "autres": forms.NumberInput(attrs={"class": "form-control"}),
            "autres_comment": forms.TextInput(attrs={"class": "form-control"}),
            "deduction": forms.NumberInput(attrs={"class": "form-control"}),
            "nb_conges": forms.NumberInput(attrs={"class": "form-control"}),
            "total_paye": forms.NumberInput(attrs={"class": "form-control"}),
            "devise": forms.TextInput(attrs={"class": "form-control"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Préremplissage automatique selon la période de la paie existante
        if self.instance and self.instance.periode:
            self.fields["mois"].initial = self.instance.periode.month
            self.fields["annee"].initial = self.instance.periode.year
        else:
            # Par défaut : mois et année courants
            today = date.today()
            self.fields["mois"].initial = today.month
            self.fields["annee"].initial = today.year

    def save(self, commit=True):
        obj = super().save(commit=False)
        mois = int(self.cleaned_data["mois"])
        annee = int(self.cleaned_data["annee"])
        # On stocke le 1er jour du mois en base
        obj.periode = date(annee, mois, 1)
        if commit:
            obj.save()
        return obj
