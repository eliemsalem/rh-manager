import os
from datetime import datetime
from django.conf import settings
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

def generate_paie_pdf(payroll, output_path):
    """
    Génère un PDF esthétique pour une fiche de paie.
    - payroll : instance de Payroll
    - output_path : chemin du fichier PDF à créer
    """

    # --- Styles de texte
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("Title", fontSize=18, alignment=1, textColor=colors.HexColor("#0a4da3"))
    section_title = ParagraphStyle("SectionTitle", fontSize=12, textColor=colors.HexColor("#0a4da3"), spaceAfter=8)
    normal = ParagraphStyle("Normal", fontSize=10, leading=14)

    doc = SimpleDocTemplate(output_path, pagesize=A4,
                            rightMargin=40, leftMargin=40, topMargin=50, bottomMargin=40)
    content = []

    # --- Logo
    logo_path = os.path.join(settings.BASE_DIR, "payroll", "static", "payroll", "images", "logo.png")
    if os.path.exists(logo_path):
        content.append(Image(logo_path, width=80, height=80))
    content.append(Spacer(1, 12))

    # --- En-tête
    title_text = f"FICHE DE PAIE — {payroll.employee.prenom} {payroll.employee.nom}"
    content.append(Paragraph(title_text, title_style))
    content.append(Spacer(1, 10))

    # --- Période
    periode_text = f"Période : {payroll.periode.strftime('%B %Y')}"
    content.append(Paragraph(periode_text, normal))
    content.append(Spacer(1, 15))

    # --- Informations générales
    info_data = [
        ["Employé :", f"{payroll.employee.prenom} {payroll.employee.nom}"],
        ["Poste :", getattr(payroll.employee, "poste", "—")],
        ["IBAN :", getattr(payroll.employee, "iban", "—")],
        ["Banque :", getattr(payroll.employee, "bank_name", "—")],
    ]
    table_info = Table(info_data, colWidths=[100, 350])
    table_info.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]))
    content.append(table_info)
    content.append(Spacer(1, 15))

    # --- Détails de la paie
    content.append(Paragraph("Détails de la rémunération", section_title))
    data = [
        ["Élément", "Montant", "Commentaire"],
        ["Salaire de base", f"{payroll.salaire_base:.2f} {payroll.devise}", ""],
        ["Heures supplémentaires", f"{payroll.heures_supp} h → {payroll.montant_heures_supp:.2f} {payroll.devise}", ""],
        ["Remboursement", f"{payroll.remboursement:.2f} {payroll.devise}", payroll.remboursement_comment or ""],
        ["Autres", f"{payroll.autres:.2f} {payroll.devise}", payroll.autres_comment or ""],
        ["Déduction", f"- {payroll.deduction:.2f} {payroll.devise}", ""],
        ["", "", ""],
        ["💰 Total net à payer", f"{payroll.total_paye:.2f} {payroll.devise}", ""],
    ]
    table = Table(data, colWidths=[200, 120, 200])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#0a4da3")),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 0.25, colors.grey),
        ('ROWBACKGROUNDS', (0, 1), (-1, -2), [colors.whitesmoke, colors.lightgrey]),
        ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor("#e8f5e9")),
        ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
    ]))
    content.append(table)
    content.append(Spacer(1, 20))

    # --- Pied de page
    today = datetime.now().strftime("%d/%m/%Y à %H:%M")
    footer_text = f"Fiche générée automatiquement le {today}"
    content.append(Paragraph(footer_text, ParagraphStyle("Footer", fontSize=8, textColor=colors.HexColor("#777"))))

    # --- Génération du PDF
    doc.build(content)
