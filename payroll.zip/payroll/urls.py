from django.urls import path
from . import views

app_name = 'payroll'



urlpatterns = [
    path('', views.payroll_list, name='payroll_list'),
    path('generate/', views.generate_month_for_actives, name='payroll_generate'),
    path('<int:pk>/edit/', views.payroll_edit, name='payroll_edit'),
    path('<int:pk>/pdf/', views.payroll_pdf, name='payroll_pdf'),
    path('bulk/<int:year>/<int:month>/zip/', views.bulk_zip_month, name='payroll_bulk_zip'),
]

